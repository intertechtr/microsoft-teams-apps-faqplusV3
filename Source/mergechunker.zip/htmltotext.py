# read an html file from disk and remove all tags. then write it back as a new file
# Usage: python htmltotext.py <inputfile> <outputfile>
# Example: python htmltotext.py test.html test.txt

import sys
import re
import os

# loop through all files in a folder
for filename in os.listdir('wiki'):
    if filename.endswith('.html'):
        # read the file
        f = open('wiki/' + filename, 'r', encoding='utf-8')
        htmlsource = f.read()
        f.close()

        # get the filename without the html extension
        filename = filename[:-5]

        # replace all html tags with a space
        html = re.sub('<[^<]+?>', ' ', htmlsource)

        # remove unnecessary space
        html = re.sub(' +', ' ', html)
        
        # write the file
        f = open('wikitextonly/' + filename + '.txt', 'w', encoding='utf-8')
        f.write(html)
        f.close()

        # end for loop
        continue
    else:
        continue

# end for loop


