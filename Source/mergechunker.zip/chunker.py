from typing import List, Optional, Tuple
import tiktoken
from typing import Generator
from langchain.text_splitter import MarkdownTextSplitter, RecursiveCharacterTextSplitter, PythonCodeTextSplitter
SENTENCE_ENDINGS = [".", "!", "?"]
WORDS_BREAKS = list(reversed([",", ";", ":", " ", "(", ")", "[", "]", "{", "}", "\t", "\n"]))

parser_factory = ParserFactory()
TOKEN_ESTIMATOR = TokenEstimator()


def chunk_content_helper_v2(
        content: str, file_format: str, file_name: Optional[str],
        token_overlap: int,
        num_tokens: int = 256
) -> Generator[Tuple[str, int, Document], None, None]:
    parser = parser_factory(file_format)
    doc = parser.parse(content, file_name=file_name)

    if file_format == "markdown":
        splitter = MarkdownTextSplitter.from_tiktoken_encoder(chunk_size=num_tokens, chunk_overlap=token_overlap)
    elif file_format == "python":
        splitter = PythonCodeTextSplitter.from_tiktoken_encoder(chunk_size=num_tokens, chunk_overlap=token_overlap)
    else:
        splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
            separators=SENTENCE_ENDINGS + WORDS_BREAKS,
            chunk_size=num_tokens, chunk_overlap=token_overlap)
    chunked_content_list = splitter.split_text(doc.content)
    for chunked_content in chunked_content_list:
        chunk_size = TOKEN_ESTIMATOR.estimate_tokens(chunked_content)
        yield chunked_content, chunk_size, doc


def chunk_content_helper_v1(
        content: str, file_format: str, file_name: Optional[str],
        token_overlap: int,
        num_tokens: int = 256
) -> Generator[Tuple[str, int, Document], None, None]:
    """
    chunk the string into chunks of num_tokens
    : param s: the parsed original sentence to be chunked based on the size of num_tokens
    : param num_tokens: number of tokens per chunk
    : return: a list of chunks
    """
    parser = parser_factory(file_format)
    doc = parser.parse(content, file_name=file_name)
    enc = tiktoken.get_encoding("gpt2")
    this_chunk = ""
    this_chunksize = 0
    for line in doc.content.split("\n"):
        line_size = len(enc.encode(line))
        if this_chunksize + line_size > num_tokens:
            yield this_chunk, this_chunksize, doc
            this_chunk = ""
            this_chunksize = 0
        this_chunk += f"\n{line}"
        this_chunksize += line_size
    if len(this_chunk) > 0:
        yield this_chunk, this_chunksize, doc