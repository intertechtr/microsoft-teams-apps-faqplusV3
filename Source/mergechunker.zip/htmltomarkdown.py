import sys
import re
import os
import markdownify

def convert_html_to_markdown(sourcedir: str, destdir: str):
    #delete all files in folder destdir
    for filename in os.listdir(destdir):
        os.remove(destdir + '/' + filename)

    # loop through all files in a folder
    for filename in os.listdir(sourcedir):
        if filename.endswith('.html'):
            # read the file
            f = open(sourcedir + '/' + filename, 'r', encoding='utf-8')
            htmlsource = f.read()
            f.close()

            # get the filename without the html extension
            filename = filename[:-5]

            html = htmlsource

            # convert all html to markdown
            html = markdownify.markdownify(html)

            # remove unnecessary space
            html = re.sub(' +', ' ', html)

            # strip space and newlines from the beginning and end of the string
            html = html.strip()
                                    
            # write the file
            f = open(destdir + '/' + filename + '.md', 'w', encoding='utf-8')
            f.write(html)
            f.close()

            # end for loop
            continue
        else:
            continue

    # end for loop

convert_html_to_markdown('wikicleanhtml', 'wikimarkdown')
