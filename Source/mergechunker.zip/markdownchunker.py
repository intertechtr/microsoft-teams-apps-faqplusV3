import os
from typing import List
from langchain.document_loaders import UnstructuredMarkdownLoader
from langchain.document_loaders import DirectoryLoader
from langchain.text_splitter import MarkdownTextSplitter

def split_markdownfiles_into_chunks(sourcedir: str, destdir: str, token_encoding: str, num_tokens: int):
    #delete all files in folder destdir
    for filename in os.listdir(destdir):
        os.remove(destdir + '/' + filename)

    loader = DirectoryLoader(sourcedir, glob="**/*.md", loader_cls=UnstructuredMarkdownLoader)
    data = loader.load()
    
    markdown_splitter = MarkdownTextSplitter.from_tiktoken_encoder(encoding_name=token_encoding, chunk_size=num_tokens, chunk_overlap=0)
    docs = markdown_splitter.split_documents(data)
    i = 0
    docsource = ''
    for doc in docs:
        if docsource == doc.metadata['source']:
            i+=1
        else:
            docsource = doc.metadata['source']
            i = 1
        filename = docsource.split('\\')[1] + '-' + str(i) + '.md' 
        f = open(destdir + '/' + filename, 'w', encoding='utf-8')
        f.write(doc.page_content)
        f.close()


split_markdownfiles_into_chunks('wikimarkdown', 'wikimarkdownchunked', 'cl100k_base', 1024)
