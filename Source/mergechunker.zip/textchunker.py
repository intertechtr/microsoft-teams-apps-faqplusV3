import os
from typing import List
from langchain.document_loaders import UnstructuredFileLoader
from langchain.document_loaders import DirectoryLoader
from langchain.text_splitter import MarkdownTextSplitter

def split_markdownfiles_into_chunks(sourcedir: str, destdir: str, token_encoding: str, num_tokens: int):
    #delete all files in folder destdir
    for filename in os.listdir(destdir):
        os.remove(destdir + '/' + filename)

    #loader = DirectoryLoader(sourcedir, glob="**/*.md")
    #data = loader.load()
    
    markdown_splitter = MarkdownTextSplitter.from_tiktoken_encoder(encoding_name=token_encoding, chunk_size=num_tokens, chunk_overlap=0)
    
    test = markdown_splitter.split_text(
        """Set Build Name in Job Config
============================

**wiki:** Jenkins/Set Build Name

**Ne i****ş****e yarar:**

* Build projelerinde isimlendirme yapısında istenilen formatı kullanmak mümkün bu özellik ile.
* TFS changeset id kullanımı her build isimlendirilmesinde, otomatik olarak kullanılabilir ve görüntülenebilir hale getirilmiştir.
* Problem oluştuğunda ve/veya inceleme vb. durumlarda ilgili build için, hangi commit source olarak kullanıldığını görüntülenen changeset id  sayesinde  bulabilirsiniz.
* Sabit metin değerleri eklenebilir. Release versiyonlama ile ilgili bilgiler eklenebilir.

              Örnek : 1.2.1-build#${BUILD\_NUMBER}-changeset#${TFS\_CHANGESET}

 


 ![](/download/attachments/23577919/image2018-2-4_21-48-16.png?version=1&modificationDate=1517766526943&api=v2)

**Nereden ula****ş****ı****l****ı****r:**

Jenkins’te hazırladığınız projeniz içerisinde Build Configuration seçeneğinden, Set Build Name bölümünden  build name oluşturan, parametrik ve/veya makro değer içeren string değeri girebilirsiniz.

 

![](/download/attachments/23577919/image2018-2-4_21-47-53.png?version=1&modificationDate=1517766526960&api=v2)

Release versiyon bilgisinin Jira vb. bir uygulamadan sağlanması durumda, parametrik olarak isimlendirme yapılabilir.")""")
    
    print(test[0])
    
    #docs = markdown_splitter.split_documents(data)
    #i = 0
    #docsource = ''
    #for doc in docs:
    #    if docsource == doc.metadata['source']:
    #        i+=1
    #    else:
    #        docsource = doc.metadata['source']
    #        i = 1



split_markdownfiles_into_chunks('wikimarkdown', 'wikimarkdownchunked', 'cl100k_base', 1024)
